<?php

$data="ABCD";

echo md5($data);

echo "<br>";

echo md5("ABCD");


?>