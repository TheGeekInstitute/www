<?php

if(!defined("include")){
    header("location:index.php");
}


$host="localhost";
$username='root';
$password="toor";
$database="Akash";

$connection=new mysqli($host,$username,$password,$database);

if($connection->connect_error){
    echo "Failed To Connect";
}



function input_filter($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }
?>


